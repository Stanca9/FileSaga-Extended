# FileSaga-Extended
A game about files trying to fight a virus that is encrypting your hard disk.
